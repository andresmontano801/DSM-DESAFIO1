package com.example.promedioestudiantes

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etStudentName = findViewById<EditText>(R.id.nombre_estudiante)
        val etNote1 = findViewById<EditText>(R.id.nota1)
        val etNote2 = findViewById<EditText>(R.id.nota2)
        val etNote3 = findViewById<EditText>(R.id.nota3)
        val etNote4 = findViewById<EditText>(R.id.nota4)
        val etNote5 = findViewById<EditText>(R.id.nota5)
        val btnCalculate = findViewById<Button>(R.id.btn_calculate)
        val tvResult = findViewById<TextView>(R.id.tv_result)

        btnCalculate.setOnClickListener {
            val name = etStudentName.text.toString()
            val note1 = etNote1.text.toString().toDoubleOrNull() ?: 0.0
            val note2 = etNote2.text.toString().toDoubleOrNull() ?: 0.0
            val note3 = etNote3.text.toString().toDoubleOrNull() ?: 0.0
            val note4 = etNote4.text.toString().toDoubleOrNull() ?: 0.0
            val note5 = etNote5.text.toString().toDoubleOrNull() ?: 0.0

            if (note1 in 0.0..10.0 && note2 in 0.0..10.0 && note3 in 0.0..10.0 &&
                note4 in 0.0..10.0 && note5 in 0.0..10.0) {

                val finalGrade = (note1 * 0.15) + (note2 * 0.15) + (note3 * 0.20) + (note4 * 0.25) + (note5 * 0.25)
                val resultMessage = if (finalGrade >= 6.0) {
                    "Estudiante $name: Aprobado con una nota final de %.2f".format(finalGrade)
                } else {
                    "Estudiante $name: Reprobado con una nota final de %.2f".format(finalGrade)
                }
                tvResult.text = resultMessage
            } else {
                tvResult.text = "Por favor ingrese notas válidas (0 a 10)."
            }
        }
    }
}
