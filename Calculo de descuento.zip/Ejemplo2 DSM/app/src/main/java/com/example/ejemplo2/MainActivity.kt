package com.example.ejemplo2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val nombre=findViewById<EditText>(R.id.nom)
        val salario=findViewById<EditText>(R.id.sal)
        val calcular=findViewById<Button>(R.id.cal)
        val total=findViewById<TextView>(R.id.total)
        val usuario=findViewById<TextView>(R.id.usuario)

        calcular.setOnClickListener{
            usuario.text = "El usuario " + nombre.text + " tiene un total de:"
            if (salario.text.toString().toInt() <= 472)
            {
                total.text =  (salario.text.toString().toInt() - salario.text.toString().toInt()*(7.25/100) - salario.text.toString().toInt()*(3.0/100)).toString()
            }
            else if (salario.text.toString().toInt() <= 895.24)
            {
                total.text = (salario.text.toString().toInt() - salario.text.toString().toInt()*(10.0/100) - 17.67 - salario.text.toString().toInt()*(7.25/100) - salario.text.toString().toInt()*(3.0/100)).toString()
            }
            else if (salario.text.toString().toInt() <= 2038.10)
            {
                total.text = (salario.text.toString().toInt() - salario.text.toString().toInt()*(20.0/100) - 60.00 - salario.text.toString().toInt()*(7.25/100) - salario.text.toString().toInt()*(3.0/100)).toString()
            }
            else if (salario.text.toString().toInt() > 2038.11)
            {
                total.text = (salario.text.toString().toInt() - salario.text.toString().toInt()*(30.0/100) - 288.57 - salario.text.toString().toInt()*(7.25/100) - salario.text.toString().toInt()*(3.0/100)).toString()
            }
        }

    }
}