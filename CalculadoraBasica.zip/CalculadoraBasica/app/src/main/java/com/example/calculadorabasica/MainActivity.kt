package com.example.calculadorabasica

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etOperando1 = findViewById<EditText>(R.id.et_operando1)
        val etOperando2 = findViewById<EditText>(R.id.et_operando2)
        val btnSuma = findViewById<Button>(R.id.btn_suma)
        val btnResta = findViewById<Button>(R.id.btn_resta)
        val btnMultiplicacion = findViewById<Button>(R.id.btn_multiplicacion)
        val btnDivision = findViewById<Button>(R.id.btn_division)
        val tvResultado = findViewById<TextView>(R.id.tv_resultado)

        btnSuma.setOnClickListener {
            val operando1 = etOperando1.text.toString().toDoubleOrNull()
            val operando2 = etOperando2.text.toString().toDoubleOrNull()
            if (operando1 != null && operando2 != null) {
                val resultado = operando1 + operando2
                tvResultado.text = "Resultado: $resultado"
            } else {
                tvResultado.text = "Por favor ingrese números válidos."
            }
        }

        btnResta.setOnClickListener {
            val operando1 = etOperando1.text.toString().toDoubleOrNull()
            val operando2 = etOperando2.text.toString().toDoubleOrNull()
            if (operando1 != null && operando2 != null) {
                val resultado = operando1 - operando2
                tvResultado.text = "Resultado: $resultado"
            } else {
                tvResultado.text = "Por favor ingrese números válidos."
            }
        }

        btnMultiplicacion.setOnClickListener {
            val operando1 = etOperando1.text.toString().toDoubleOrNull()
            val operando2 = etOperando2.text.toString().toDoubleOrNull()
            if (operando1 != null && operando2 != null) {
                val resultado = operando1 * operando2
                tvResultado.text = "Resultado: $resultado"
            } else {
                tvResultado.text = "Por favor ingrese números válidos."
            }
        }

        btnDivision.setOnClickListener {
            val operando1 = etOperando1.text.toString().toDoubleOrNull()
            val operando2 = etOperando2.text.toString().toDoubleOrNull()
            if (operando1 != null && operando2 != null) {
                if (operando2 != 0.0) {
                    val resultado = operando1 / operando2
                    tvResultado.text = "Resultado: $resultado"
                } else {
                    tvResultado.text = "Error: División por cero no es válido."
                }
            } else {
                tvResultado.text = "Por favor ingrese números válidos."
            }
        }
    }
}
